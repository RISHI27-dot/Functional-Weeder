defmodule Task4CClientRobotB.Position do
  defstruct x: 1, y: :a, facing: :north
end
