defmodule Makeup.Formatter do
  @moduledoc false
end
